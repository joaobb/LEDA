package sorting.divideAndConquer;

import sorting.AbstractSorting;

public class test<T extends Comparable<T>> extends AbstractSorting<T> {

   @Override
   public void sort(T[] array, int leftIndex, int rightIndex) {

   }
}